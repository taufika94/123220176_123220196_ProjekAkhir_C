/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


package connection;
import com.mysql.cj.jdbc.MysqlDataSource;
import java.sql.*;

/**
 *
 * @author Irsyad
 */
public class Connector{
    static Connection connect;
    
    public static Connection connect(){
        if (connect==null){
            MysqlDataSource data = new MysqlDataSource();
            data.setDatabaseName("zoo");
            data.setUser("root");
            data.setPassword("");
            try{
                connect = data.getConnection();
                System.out.println("Connected To Zoo Database");
            }catch(SQLException e){
                e.printStackTrace();
                System.out.println("Connection Failed");
            }
            
        }
        return connect;
    }
}
