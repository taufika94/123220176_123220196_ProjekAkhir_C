/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.Date;

/**
 *
 * @author Irsyad
 */
public class Pengunjung {
    private Date tanggal;
    private String hari;
    private int jumlahpengunjung,total;

    public Date getTanggal() {
        return tanggal;
    }

    public void setTanggal(Date tanggal) {
        this.tanggal = tanggal;
    }

    public String getHari() {
        return hari;
    }

    public void setHari(String hari) {
        this.hari = hari;
    }

    public int getJumlahpengunjung() {
        return jumlahpengunjung;
    }

    public void setJumlahpengunjung(int jumlahpengunjung) {
        this.jumlahpengunjung = jumlahpengunjung;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }
    
}
