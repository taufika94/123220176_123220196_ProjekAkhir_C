/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Irsyad
 */
public class ModelTableHewan extends AbstractTableModel{
    List<Hewan> dz;
    public ModelTableHewan (List<Hewan>dz){
        this.dz  = dz;
    }
    

    @Override
    public int getRowCount() {
         return dz.size();
    }

    @Override
    public int getColumnCount() {
        return 7;
    }
    
    @Override
    public String getColumnName(int column){
        switch(column){
            case 0:
                return "Id";
            case 1:
                return "Nama";
            case 2:
                return "Jenis Hewan";
            case 3:
                return "Habitat";
            case 4:
                return "Tahun Masuk";
            case 5:
                return "Jenis Kelamin";
            case 6:
                return "Asal";
            default:
                return null;
        }
    }

    @Override
    public Object getValueAt(int row, int column) {
        switch(column){
            case 0:
                return dz.get(row).getId();
            case 1:
                return dz.get(row).getNama();
            case 2:
                return dz.get(row).getJenishewan();
            case 3:
                return dz.get(row).getHabitat();
            case 4:
                return dz.get(row).getTahunmasuk();
            case 5:
                return dz.get(row).getJeniskelamin();
            case 6:
                return dz.get(row).getAsal();
            default:
                return null;
        }
    }
    
    
}
