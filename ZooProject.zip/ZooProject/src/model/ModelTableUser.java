/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Irsyad
 */
public class ModelTableUser extends AbstractTableModel{
    List<User> du;
    
    public ModelTableUser(List<User> du){
        this.du = du;
    }

    @Override
    public int getRowCount() {
        return du.size();
    }

    @Override
    public int getColumnCount() {
        return 2;
    }
    
    @Override
    public String getColumnName(int column){
        switch(column){
            case 0:
                return "Username";
            case 1:
                return "Password";
            default:
                return null;
        }
    }

    @Override
    public Object getValueAt(int row, int column) {
        switch(column){
            case 0:
                return du.get(row).getUser();
            case 1:
                return du.get(row).getPassword();
            default:
                return null;
        }
    }
    
}
