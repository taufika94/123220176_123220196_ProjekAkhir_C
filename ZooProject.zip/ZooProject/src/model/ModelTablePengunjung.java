/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Irsyad
 */
public class ModelTablePengunjung extends AbstractTableModel{
    List<Pengunjung> dp;
    
    public ModelTablePengunjung(List<Pengunjung> dp){
        this.dp = dp;
    }

    @Override
    public int getRowCount() {
        return dp.size();
    }

    @Override
    public int getColumnCount() {
         return 4;
    }
    
    @Override
    public String getColumnName(int column){
        switch(column){
            case 0:
                return "Tanggal";
            case 1:
                return "Jumlah Pengunjung";
            case 2:
                return "Hari";
            case 3:
                return "Total Pemasukan";
            default:
                return null;
        }
    }

    @Override
    public Object getValueAt(int row, int column) {
        switch(column){
            case 0:
                return dp.get(row).getTanggal();
            case 1:
                return dp.get(row).getJumlahpengunjung();
            case 2:
                return dp.get(row).getHari();
            case 3:
                return dp.get(row).getTotal();
            default:
                return null;
        }
    }
    
}
