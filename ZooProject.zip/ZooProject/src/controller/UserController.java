/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;
import java.util.List;
import DAOZoo.UserDAO;
import model.*;
import view.*;
import com.mysql.cj.jdbc.MysqlDataSource;
import java.sql.*;
import java.util.InputMismatchException;
import javax.swing.*;
import DAOImplements.UserImplement;

/**
 *
 * @author Irsyad
 */
public class UserController {
    UIUser frame;
    UserImplement impuser;
    List<User> du;
    
    public UserController(UIUser frame){
        this.frame = frame;
        impuser = new UserDAO();
        du = impuser.getAll();
    }
    
    public void tablecontent(){
        du = impuser.getAll();
        ModelTableUser table = new ModelTableUser(du);
        frame.getTableUser().setModel(table);
    }
    
    public void delete(String username){
        try{
            if(username == null){
            JOptionPane.showMessageDialog(frame, "Penghapusan Gagal, Pilih Data yang Ingin Dihapus !","Gagal",JOptionPane.ERROR_MESSAGE);
            }
            else{
            int conf =JOptionPane.showOptionDialog(frame, "Yakin Ingin Mengapus Data ?","Konfirmasi",JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE,null,null,null);
            if (conf == JOptionPane.YES_OPTION){
            User du = new User();
            du.setUser(username);
            impuser.delete(du);
            JOptionPane.showMessageDialog(frame, "Data Berhasil Dihapus !","Berhasil",JOptionPane.INFORMATION_MESSAGE);  
            }
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(frame, "Data Gagal Dihapus !","Gagal",JOptionPane.ERROR_MESSAGE);
        }
    }
    
}
