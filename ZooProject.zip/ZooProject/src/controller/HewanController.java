/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;
import java.util.List;
import DAOZoo.HewanDAO;
import model.*;
import view.*;
import com.mysql.cj.jdbc.MysqlDataSource;
import java.sql.*;
import java.util.InputMismatchException;
import javax.swing.*;
import DAOImplements.HewanImplement;

/**
 *
 * @author Irsyad
 */
public class HewanController {
    UIHewan frame;
    HewanImplement imphewan;
    List<Hewan> dz;
    
    public HewanController(UIHewan frame){
        this.frame=frame;
        imphewan = new HewanDAO();
        dz = imphewan.getAll();
    }
    
    public void tablecontent(){
        dz = imphewan.getAll();
        ModelTableHewan model = new ModelTableHewan(dz);
        frame.getTableHewan().setModel(model);
    }
    
    public void insert(String kelamin,String habitat,String jenis){
        try{
            if(frame.getjTextFieldNamaHewan().getText().equals("") || kelamin == null || habitat == null ||frame.getjTextFieldTahunMasuk().getText().equals("") || frame.getjTextFieldAsal().getText().equals("")){
            JOptionPane.showMessageDialog(frame, "Penambahan Gagal, Masukan Semua Informasi !","Gagal",JOptionPane.ERROR_MESSAGE);
            }
            else{
            Hewan dz = new Hewan();
            dz.setNama(frame.getjTextFieldNamaHewan().getText());
            dz.setJenishewan(jenis);
            dz.setHabitat(habitat);
            try{
                dz.setTahunmasuk(Integer.valueOf(frame.getjTextFieldTahunMasuk().getText()));
            }catch(NumberFormatException e){
                JOptionPane.showMessageDialog(frame, "Mohon Masukan Tahun yang Valid !","Error",JOptionPane.ERROR_MESSAGE);
                return;
            }
            if(dz.getTahunmasuk()<=0){
            JOptionPane.showMessageDialog(frame, "Mohon Masukan Tahun yang Valid !","Error",JOptionPane.ERROR_MESSAGE);
            }else{
            dz.setJeniskelamin(kelamin);
            dz.setAsal(frame.getjTextFieldAsal().getText());
            imphewan.insert(dz);
            JOptionPane.showMessageDialog(frame,"Data Berhasil Ditambahkan !","Berhasil",JOptionPane.INFORMATION_MESSAGE);
            }   
            }   
        }catch(InputMismatchException e){
            JOptionPane.showMessageDialog(frame, "Data Gagal Ditambahkan !","Gagal",JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void update(String kelamin,String habitat,String id,String jenis){
        try{
            if(frame.getjTextFieldNamaHewan().getText().equals("") || kelamin == null || id == null || habitat == null || frame.getjTextFieldTahunMasuk().getText().equals("") || frame.getjTextFieldAsal().getText().equals("")){
            JOptionPane.showMessageDialog(frame, "Pengupdatean Gagal, Pilih Data yang Ingin Diupdate atau Masukan semua Informasi !","Gagal",JOptionPane.ERROR_MESSAGE);
            }
            else{
            Hewan dz = new Hewan();
            dz.setNama(frame.getjTextFieldNamaHewan().getText());
            dz.setJenishewan(jenis);
            dz.setHabitat(habitat);
            dz.setTahunmasuk(Integer.valueOf(frame.getjTextFieldTahunMasuk().getText()));
            dz.setJeniskelamin(kelamin);
            dz.setAsal(frame.getjTextFieldAsal().getText());
            dz.setId(Integer.parseInt(id));
            imphewan.update(dz);
            JOptionPane.showMessageDialog(frame, "Data Berhasil Diupdate","Berhasil",JOptionPane.INFORMATION_MESSAGE);    
            } 
        }catch(InputMismatchException e){
            JOptionPane.showMessageDialog(frame, "Data Gagal Diupdate !","Gagal",JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void delete(String id){
        if(frame.getjTextFieldNamaHewan().getText().equals("")){
        JOptionPane.showMessageDialog(frame, "Penghapusan Gagal, Pilih Data yang Ingin Dihapus !","Gagal",JOptionPane.ERROR_MESSAGE);
        }
        else{
        int conf =JOptionPane.showOptionDialog(frame, "Yakin Ingin Mengapus Data ?","Konfirmasi",JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE,null,null,null);
        if (conf == JOptionPane.YES_OPTION){
        imphewan.delete(id);
        JOptionPane.showMessageDialog(frame, "Data Berhasil Dihapus !","Berhasil",JOptionPane.WARNING_MESSAGE);
        }
    }
    }
    
    public void truncate(){
        int conf = JOptionPane.showOptionDialog(frame, "Yakin Ingin Menghapus Semua Data ?","Konfirmasi",JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE,null,null,null);
        if(conf == JOptionPane.YES_OPTION){
            imphewan.truncate();
        }
    }
}
