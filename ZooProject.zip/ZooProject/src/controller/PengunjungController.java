/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;
import java.util.List;
import DAOZoo.PengunjungDAO;
import model.*;
import view.*;
import com.mysql.cj.jdbc.MysqlDataSource;
import java.sql.*;
import java.util.InputMismatchException;
import javax.swing.*;
import DAOImplements.PengunjungImplement;

/**
 *
 * @author Irsyad
 */
public class PengunjungController {
    UIPengunjung frame;
    PengunjungImplement imppengunjung;
    List<Pengunjung> dp;
    final Integer harga_hari_kerja=50000,harga_hari_libur=75000;
    
    public PengunjungController(UIPengunjung frame){
        this.frame=frame;
        imppengunjung = new PengunjungDAO();
        dp = imppengunjung.getAll();
    }
    
    public void tablecontent(){
        dp = imppengunjung.getAll();
        ModelTablePengunjung model = new ModelTablePengunjung(dp);
        frame.getjTablePengunjung().setModel(model);
    }
    
    public void insert(java.util.Date tanggal,String jmlpengunjung,String hari){
        try{
            if(tanggal==null || jmlpengunjung.equals(0) || hari.equals("")){
            JOptionPane.showMessageDialog(frame, "Penambahan Gagal, Masukan Semua Informasi !","Gagal",JOptionPane.ERROR_MESSAGE);
            }
            else{
            Pengunjung dp = new Pengunjung();
            dp.setTanggal(tanggal);
            dp.setJumlahpengunjung(Integer.parseInt(jmlpengunjung));
            if(dp.getJumlahpengunjung()<=0){
                JOptionPane.showMessageDialog(frame, "Mohon Masukan Jumlah yang Valid !","Error",JOptionPane.ERROR_MESSAGE);
            }
            else{
                dp.setHari(hari);
            if(hari=="Hari Kerja"){
                dp.setTotal(Integer.parseInt(jmlpengunjung)*harga_hari_kerja);
            }
            else{
                dp.setTotal(Integer.parseInt(jmlpengunjung)*harga_hari_libur);
            }
            imppengunjung.insert(dp);
            }
            
            }
            
        }catch(InputMismatchException e){
            JOptionPane.showMessageDialog(frame, "Data Gagal Ditambahkan !","Gagal",JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void delete(java.util.Date tanggal){
        if(tanggal==null){
        JOptionPane.showMessageDialog(frame, "Penghapusan Gagal, Pilih Data yang Ingin Dihapus !","Gagal",JOptionPane.ERROR_MESSAGE);
        }
        else{
        int conf =JOptionPane.showOptionDialog(frame, "Yakin Ingin Mengapus Data ?","Konfirmasi",JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE,null,null,null);
        if (conf == JOptionPane.YES_OPTION){
        imppengunjung.delete(tanggal);
        JOptionPane.showMessageDialog(frame, "Data Berhasil Dihapus !","Berhasil",JOptionPane.WARNING_MESSAGE);
        }
    }
    }
}
