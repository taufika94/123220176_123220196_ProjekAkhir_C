/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;
import java.util.List;
import DAOZoo.UserDAO;
import model.*;
import view.*;
import com.mysql.cj.jdbc.MysqlDataSource;
import java.sql.*;
import java.util.InputMismatchException;
import javax.swing.*;
import DAOImplements.UserImplement;

/**
 *
 * @author Irsyad
 */
public class LoginController {
    UILogin frame;
    UserImplement impuser;
    List<User> du;
    
    public LoginController(UILogin frame){
        this.frame=frame;
        impuser = new UserDAO();
        du = impuser.getAll();
    }
    
    
    public void insert(){
        try{
            if(frame.getjTextFieldUsername().getText().equals("") || frame.getjTextFieldPassword().getText().equals("")){
            JOptionPane.showMessageDialog(frame, "Mohon Masukan Username dan Password untuk Mendaftar !","Gagal",JOptionPane.WARNING_MESSAGE);
            }else{
            User du = new User();
            du.setUser(frame.getjTextFieldUsername().getText());
            du.setPassword(frame.getjTextFieldPassword().getText());
            impuser.insert(du);   
            }
        
        }catch(Exception e){
            JOptionPane.showMessageDialog(frame, "Data Gagal Ditambahkan !","Gagal",JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void checklogin(){
        try{
            User du = new User();
            du.setUser(frame.getjTextFieldUsername().getText());
            du.setPassword(frame.getjTextFieldPassword().getText());
            if(!impuser.checklogin(du)){
                JOptionPane.showMessageDialog(frame, "Username atau Password Salah !","Gagal",JOptionPane.ERROR_MESSAGE);
                return;
            }
            UIMenu menupage = new UIMenu();
                menupage.setVisible(true);
                menupage.setLocationRelativeTo(null);
                frame.dispose();
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
    }

}
