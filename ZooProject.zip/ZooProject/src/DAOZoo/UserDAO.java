/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAOZoo;
import java.sql.*;
import java.util.*;
import connection.*;
import model.*;
import java.util.logging.*;
import view.*;
import DAOImplements.UserImplement;
import controller.LoginController;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import java.sql.*;

/**
 *
 * @author Irsyad
 */
public class UserDAO implements UserImplement {
    Connection connection;
    UILogin frame;
    
    public String status;
    final String select = "select * from user";
    final String insert = "insert into user (username,password) values (?,?)";
    final String delete = "delete from user where username=?";
    
    public UserDAO(){
        connection = Connector.connect();
    }

    @Override
    public void insert(User u) {
        PreparedStatement statement = null;
        try{
            statement = connection.prepareStatement(insert,Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, u.getUser());
            statement.setString(2, u.getPassword());
            statement.executeUpdate();
            JOptionPane.showMessageDialog(frame, "Pendaftaran User Baru Berhasil !","Berhasil",JOptionPane.INFORMATION_MESSAGE);
        }catch(SQLIntegrityConstraintViolationException e){
            JOptionPane.showMessageDialog(frame, "Pendaftaran Gagal, User sudah ada !","Gagal",JOptionPane.ERROR_MESSAGE);
        } catch (SQLException ex) {
            Logger.getLogger(UserDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try{
                statement.close();
            }catch(SQLException e){
                e.printStackTrace();
            }
        }
    }

    @Override
    public void delete(User u) {
        PreparedStatement statement = null;
        try{
            statement = connection.prepareStatement(delete);
            statement.setString(1, u.getUser());
            statement.executeUpdate();
        }catch(SQLException e){
            e.printStackTrace();
        }finally{
            try{
                statement.close();
            }catch(SQLException e){
                e.printStackTrace();
            }
        }
    }

    @Override
    public List<User> getAll() {
        List<User> du =null;
        try{
            du = new ArrayList<User>();
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(select);
            while(rs.next()){
                User user = new User();
                user.setUser(rs.getString("username"));
                user.setPassword(rs.getString("password"));
                du.add(user);
            }
            
        }catch(SQLException e){
            Logger.getLogger(UserDAO.class.getName()).log(Level.SEVERE,null,e);
        }
        return du;
    }
    
    @Override
    public Boolean checklogin(User u){
        try{
            Statement statement = connection.createStatement();
            String user=u.getUser();
            String pass=u.getPassword();
            String query = "select * from user where username ='"+user+"' and password ='"+pass+"'";
            ResultSet rs = statement.executeQuery(query);
            if (rs.next()){
                return true;
            }
            else{
                return false;
            }
            
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
        return false;
    }
    
}
