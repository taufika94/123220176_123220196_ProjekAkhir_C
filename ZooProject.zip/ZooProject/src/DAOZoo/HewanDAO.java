/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAOZoo;
import java.sql.*;
import java.util.*;
import connection.*;
import model.*;
import java.util.logging.*;
import view.*;
import DAOImplements.HewanImplement;


/**
 *
 * @author Irsyad
 */
public class HewanDAO implements HewanImplement {
    Connection connection;
    UIHewan frame;
    final String select = "select * from hewan";
    final String insert = "insert into hewan (Nama,JenisHewan,Habitat,TahunMasuk,JenisKelamin,Asal) values (?,?,?,?,?,?)";
    final String update = "update hewan set Nama=?,JenisHewan=?,Habitat=?,TahunMasuk=?,JenisKelamin=?,Asal=? where id=?";
    final String delete = "delete from hewan where id=?";
    final String truncate = "truncate table hewan";
    
    public HewanDAO(){
        connection = Connector.connect();
    }
    
    @Override
    public void insert(Hewan z) {
        PreparedStatement statement = null;
        try{
            statement = connection.prepareStatement(insert,Statement.RETURN_GENERATED_KEYS);
            statement.setString(1,z.getNama());
            statement.setString(2,z.getJenishewan());
            statement.setString(3,z.getHabitat());
            statement.setInt(4,z.getTahunmasuk());
            statement.setString(5,z.getJeniskelamin());
            statement.setString(6,z.getAsal());
            statement.executeUpdate();
            ResultSet rs = statement.getGeneratedKeys();
            while(rs.next()){
                z.setId(rs.getInt(1));
            }
        }catch(SQLException e){
            e.printStackTrace();
        }finally{
            try{
                statement.close();
            }catch(SQLException e){
                e.printStackTrace();
            }
        }
    }

    @Override
    public void update(Hewan z) {
         PreparedStatement statement = null;
        try{
            statement = connection.prepareStatement(update);
            statement.setString(1,z.getNama());
            statement.setString(2,z.getJenishewan());
            statement.setString(3,z.getHabitat());
            statement.setInt(4,z.getTahunmasuk());
            statement.setString(5,z.getJeniskelamin());
            statement.setString(6,z.getAsal());
            statement.setInt(7,z.getId());
            statement.executeUpdate();
        }catch(SQLException e){
            e.printStackTrace();
        }finally{
            try{
                statement.close();
            }catch(SQLException e){
                e.printStackTrace();
            }
        }
    }

    @Override
    public void delete(String id) {
        PreparedStatement statement = null;
        try{
            statement = connection.prepareStatement(delete);
            statement.setString(1,id);
            statement.executeUpdate();
            
        }catch(SQLException e){
            e.printStackTrace();
        }finally{
            try{
                statement.close();
            }catch(SQLException e){
                e.printStackTrace();
            }
        }
    }

    @Override
    public List<Hewan> getAll() {
        List<Hewan> dz = null;
        try{
            dz = new ArrayList<Hewan>();
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(select);
            while(rs.next()){
                Hewan zoo = new Hewan();
                zoo.setId(rs.getInt("id"));
                zoo.setNama(rs.getString("Nama"));
                zoo.setJenishewan(rs.getString("JenisHewan"));
                zoo.setHabitat(rs.getString("Habitat"));
                zoo.setTahunmasuk(rs.getInt("TahunMasuk"));
                zoo.setJeniskelamin(rs.getString("JenisKelamin"));
                zoo.setAsal(rs.getString("Asal"));
                dz.add(zoo);
            }
            
        }catch(SQLException e){
            Logger.getLogger(HewanDAO.class.getName()).log(Level.SEVERE,null,e);
        }
        return dz;
    }

    @Override
    public void truncate() {
        PreparedStatement statement = null;
        try{
            statement = connection.prepareStatement(truncate);
            statement.executeUpdate();
        }catch(SQLException e){
            e.printStackTrace();
        }finally{
            try{
                statement.close();
            }catch(SQLException e){
                e.printStackTrace();
            }
        }
    }
    
}
