/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAOZoo;
import java.sql.*;
import java.util.*;
import connection.*;
import model.*;
import java.util.logging.*;
import view.*;
import DAOImplements.PengunjungImplement;
import controller.PengunjungController;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import java.sql.*;

/**
 *
 * @author Irsyad
 */
public class PengunjungDAO implements PengunjungImplement{
    Connection connection;
    UIPengunjung frame;
    final String select = "select * from pengunjung";
    final String insert = "insert into pengunjung (tanggal,jumlahpengunjung,hari,total) values (?,?,?,?)";
    final String delete = "delete from pengunjung where tanggal=?";

    public PengunjungDAO(){
        connection = Connector.connect();
    }
    
    @Override
    public void insert(Pengunjung p) {
         PreparedStatement statement = null;
        try{
            statement = connection.prepareStatement(insert,Statement.RETURN_GENERATED_KEYS);
            statement.setDate(1,new java.sql.Date(p.getTanggal().getTime()));
            statement.setInt(2, p.getJumlahpengunjung());
            statement.setString(3, p.getHari());
            statement.setInt(4, p.getTotal());
            statement.executeUpdate();
            JOptionPane.showMessageDialog(frame, "Data Pengunjung Berhasil Ditambahkan !","Berhasil",JOptionPane.INFORMATION_MESSAGE);
        }catch(SQLIntegrityConstraintViolationException e){
            JOptionPane.showMessageDialog(frame, "Tanggal Penginputan Sudah Ada !","Error",JOptionPane.ERROR_MESSAGE);
        }
        catch (SQLException ex) {
            Logger.getLogger(UserDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try{
                statement.close();
            }catch(SQLException e){
                e.printStackTrace();
            }
        }
    }

    @Override
    public List<Pengunjung> getAll() {
        List<Pengunjung> dp =null;
        try{
            dp = new ArrayList<Pengunjung>();
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(select);
            while(rs.next()){
                Pengunjung pengunjung = new Pengunjung();
                pengunjung.setTanggal(rs.getDate("tanggal"));
                pengunjung.setJumlahpengunjung(rs.getInt("jumlahpengunjung"));
                pengunjung.setHari(rs.getString("hari"));
                pengunjung.setTotal(rs.getInt("total"));
                dp.add(pengunjung);
            }
            
        }catch(SQLException e){
            Logger.getLogger(UserDAO.class.getName()).log(Level.SEVERE,null,e);
        }
        return dp;
    }

    @Override
    public void delete(java.util.Date tanggal) {
        PreparedStatement statement = null;
        try{
            statement = connection.prepareStatement(delete);
            statement.setDate(1,new java.sql.Date(tanggal.getTime()));
            statement.executeUpdate();
        }catch(SQLException e){
            e.printStackTrace();
        }finally{
            try{
                statement.close();
            }catch(SQLException e){
                e.printStackTrace();
            }
        }
    }
    
}
