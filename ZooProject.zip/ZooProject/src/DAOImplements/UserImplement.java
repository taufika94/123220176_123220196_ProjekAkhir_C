/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAOImplements;
import java.util.List;
import model.*;

/**
 *
 * @author Irsyad
 */
public interface UserImplement {
    public Boolean checklogin(User u);
    public void insert(User u);
    public void delete(User u);
    public List<User> getAll();
}
