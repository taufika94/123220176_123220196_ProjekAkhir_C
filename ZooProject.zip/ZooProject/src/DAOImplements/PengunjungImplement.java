/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAOImplements;
import java.util.Date;
import model.*;
import java.util.List;

/**
 *
 * @author Irsyad
 */
public interface PengunjungImplement {
    public void insert(Pengunjung p);
    public void delete(Date tanggal);
    public List<Pengunjung> getAll();
}
